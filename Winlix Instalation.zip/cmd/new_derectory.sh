cd ..
git init "new derectory"
echo derectory created