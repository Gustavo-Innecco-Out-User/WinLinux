cd ..
vim